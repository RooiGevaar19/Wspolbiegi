gcc scrabble_new.c -o scrabble.app -lX11 -std=c99
